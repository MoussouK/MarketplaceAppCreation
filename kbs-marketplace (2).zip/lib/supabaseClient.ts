import { createClient } from '@supabase/supabase-js';

// Environment variables would typically be used here
// For this environment, we will check if they exist, otherwise we might fail gracefully or use placeholders
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'placeholder';

export const supabase = createClient(supabaseUrl, supabaseKey);