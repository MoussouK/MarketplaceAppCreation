import { GoogleGenAI, Type } from "@google/genai";

export const generateListingDetails = async (base64Image: string) => {
  if (!process.env.API_KEY) {
    throw new Error("API Key not found");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const systemInstruction = `
    You are an expert reseller and appraiser for a circular economy marketplace.
    Analyze the provided image and generate listing details in a structured JSON format.
    Be concise, attractive, and accurate.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image
            }
          },
          {
            text: "Generate a title, description, suggested price (in cents), condition, and category for this item."
          }
        ]
      },
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: "A catchy, short title for the listing" },
            description: { type: Type.STRING, description: "A friendly, detailed description of the item" },
            price_cents: { type: Type.INTEGER, description: "Estimated value in cents" },
            category: { type: Type.STRING, description: "One word category (e.g. Furniture, Clothing)" },
            condition: { 
              type: Type.STRING, 
              enum: ['New', 'Like New', 'Used - Good', 'Used - Fair', 'For Parts'] 
            }
          }
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
