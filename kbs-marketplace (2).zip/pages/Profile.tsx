import React, { useEffect, useState } from 'react';
import { Settings, LogOut, HelpCircle, User, MapPin, Star, ChevronRight, Package } from 'lucide-react';
import ListingCard from '../components/ListingCard';
import { Listing, AppUser } from '../types/database';
import { generateMockListings } from '../lib/utils';
import { useNavigate } from 'react-router-dom';

const Profile = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<AppUser | null>(null);
  const [myListings, setMyListings] = useState<Listing[]>([]);

  useEffect(() => {
    // Mock User Data
    const mockUser: AppUser = {
      id: 'current-user',
      name: 'Bob Builder',
      city: 'Florence',
      zip: '41042',
      reputation_score: 4.9,
      karma_points: 350,
      avatar_url: 'https://i.pravatar.cc/150?u=BobBuilder'
    };
    setUser(mockUser);

    // Mock User Listings - Filter logic would happen on backend usually
    const allListings = generateMockListings() as Listing[];
    // Assign a couple to this user for demo
    const userListings = allListings.slice(2, 5); 
    setMyListings(userListings);
  }, []);

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Profile Header */}
      <div className="bg-white p-6 pb-8 rounded-b-[2.5rem] shadow-sm relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-r from-primary-100 to-primary-200 opacity-50"></div>
        
        <div className="relative pt-8 flex flex-col items-center">
          <div className="w-24 h-24 rounded-full p-1 bg-white shadow-lg mb-3">
            <img 
              src={user.avatar_url} 
              alt={user.name} 
              className="w-full h-full rounded-full object-cover"
            />
          </div>
          
          <h1 className="text-2xl font-bold text-gray-900 mb-1">{user.name}</h1>
          
          <div className="flex items-center gap-4 text-sm text-gray-600 mb-6">
            <div className="flex items-center gap-1">
              <MapPin size={14} />
              <span>{user.city}, KY</span>
            </div>
            <div className="flex items-center gap-1">
              <Star size={14} className="fill-yellow-400 text-yellow-400" />
              <span className="font-bold text-gray-900">{user.reputation_score}</span>
              <span className="text-gray-400">(42)</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 w-full max-w-xs">
            <div className="bg-gray-50 p-3 rounded-2xl text-center border border-gray-100">
                <div className="text-2xl font-bold text-gray-900">{user.karma_points}</div>
                <div className="text-xs font-medium text-gray-500 uppercase tracking-wide">Karma Pts</div>
            </div>
            <div className="bg-gray-50 p-3 rounded-2xl text-center border border-gray-100">
                <div className="text-2xl font-bold text-gray-900">{myListings.length}</div>
                <div className="text-xs font-medium text-gray-500 uppercase tracking-wide">Active Listings</div>
            </div>
          </div>
        </div>
      </div>

      {/* My Listings Section */}
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-lg text-gray-900">My Listings</h2>
            <button className="text-primary-600 text-sm font-semibold">See All</button>
        </div>
        
        {myListings.length > 0 ? (
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 -mx-6 px-6">
            {myListings.map(listing => (
              <div key={listing.id} className="min-w-[160px] w-[160px]">
                <ListingCard listing={listing} />
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white border border-dashed border-gray-300 rounded-2xl p-6 text-center">
             <Package className="mx-auto text-gray-300 mb-2" size={32} />
             <p className="text-sm text-gray-500 mb-3">You haven't listed anything yet.</p>
             <button onClick={() => navigate('/sell')} className="text-primary-600 text-sm font-bold">Start Selling</button>
          </div>
        )}
      </div>

      {/* Menu Actions */}
      <div className="px-6 pb-8">
        <h2 className="font-bold text-lg text-gray-900 mb-4">Account</h2>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden divide-y divide-gray-50">
            <MenuItem 
              icon={<User size={20} />} 
              label="Edit Profile" 
              onClick={() => navigate('/profile/edit')} 
            />
            <MenuItem 
              icon={<Settings size={20} />} 
              label="Settings" 
              onClick={() => navigate('/settings')} 
            />
            <MenuItem 
              icon={<HelpCircle size={20} />} 
              label="Help & Support" 
              onClick={() => navigate('/support')} 
            />
            <MenuItem 
              icon={<LogOut size={20} />} 
              label="Log Out" 
              isDestructive 
              onClick={() => navigate('/')} 
            />
        </div>
        
        <p className="text-center text-xs text-gray-400 mt-8 mb-4">
            Version 1.0.0 (Beta)
        </p>
      </div>
    </div>
  );
};

const MenuItem = ({ icon, label, isDestructive, onClick }: { icon: React.ReactNode, label: string, isDestructive?: boolean, onClick?: () => void }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors ${isDestructive ? 'text-red-500' : 'text-gray-700'}`}
  >
    <div className="flex items-center gap-3">
        <span className={isDestructive ? 'text-red-500' : 'text-gray-400'}>{icon}</span>
        <span className="font-medium text-sm">{label}</span>
    </div>
    <ChevronRight size={16} className="text-gray-300" />
  </button>
);

export default Profile;