import React, { useState, useEffect } from 'react';
import { SlidersHorizontal, Search, RotateCcw, Plus } from 'lucide-react';
import ListingCard from '../components/ListingCard';
import { Listing, Circle } from '../types/database';
import { generateMockListings, generateMockCircles } from '../lib/utils';
import FilterModal, { FilterState } from '../components/FilterModal';
import NotificationBell from '../components/NotificationBell';
import StoriesTray from '../components/StoriesTray';
import LocationPicker from '../components/LocationPicker';

const HomeFeed = () => {
  // Data State
  const [listings, setListings] = useState<Listing[]>([]);
  const [filteredListings, setFilteredListings] = useState<Listing[]>([]);
  
  // Location State
  const [selectedCircle, setSelectedCircle] = useState<Circle | null>(null);

  // UI State
  const [activeChip, setActiveChip] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  
  // Filter State
  const [filters, setFilters] = useState<FilterState>({
    distance: 25, // Default larger distance
    priceMin: '',
    priceMax: '',
    condition: [],
    sortBy: 'newest'
  });

  // Initial Load: Circles & Listings
  useEffect(() => {
    // 1. Load Circles & Preferred Selection
    const circles = generateMockCircles();
    const savedCircleId = localStorage.getItem('kbs_preferred_circle');
    
    if (savedCircleId) {
        const found = circles.find(c => c.id === savedCircleId);
        setSelectedCircle(found || circles[0]);
    } else {
        setSelectedCircle(circles[0]); // Default to first (Brooklyn)
    }

    // 2. Load Listings (Mock)
    const data = generateMockListings() as Listing[]; 
    setListings(data);
  }, []);

  // Handle Location Selection
  const handleLocationSelect = (circle: Circle) => {
    setSelectedCircle(circle);
    localStorage.setItem('kbs_preferred_circle', circle.id);
  };

  // Main Filtering Logic
  useEffect(() => {
    if (!selectedCircle) return;

    let result = [...listings];

    // 0. Location Filter (Hub Logic)
    // Only show items in the selected circle
    if (selectedCircle) {
        result = result.filter(l => l.circle_id === selectedCircle.id);
    }

    // 1. Chip Filter
    if (activeChip !== 'All') {
      if (activeChip === 'Donation') {
        result = result.filter(l => l.type === 'DONATION');
      } else if (activeChip === 'Trade') {
        result = result.filter(l => l.type === 'TRADE');
      } else if (activeChip === 'For Sale') {
        result = result.filter(l => l.type === 'SALE');
      }
    }

    // 2. Search Filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(l => 
        l.title.toLowerCase().includes(q) || 
        l.description.toLowerCase().includes(q)
      );
    }

    // 3. Modal Filters
    // Distance 
    if (filters.distance) {
      result = result.filter(l => (l.distance || 0) <= filters.distance);
    }

    // Price
    if (filters.priceMin) {
      const min = parseFloat(filters.priceMin) * 100; // cents
      result = result.filter(l => l.price_cents >= min);
    }
    if (filters.priceMax) {
      const max = parseFloat(filters.priceMax) * 100; // cents
      result = result.filter(l => l.price_cents <= max);
    }

    // Condition
    if (filters.condition.length > 0) {
      result = result.filter(l => filters.condition.includes(l.condition));
    }

    // Sort
    if (filters.sortBy === 'price_asc') {
      result.sort((a, b) => a.price_cents - b.price_cents);
    } else if (filters.sortBy === 'price_desc') {
      result.sort((a, b) => b.price_cents - a.price_cents);
    } else if (filters.sortBy === 'closest') {
      result.sort((a, b) => (a.distance || 0) - (b.distance || 0));
    }

    setFilteredListings(result);
  }, [listings, activeChip, searchQuery, filters, selectedCircle]);

  const handleApplyFilters = (newFilters: FilterState) => {
    setFilters(newFilters);
    setIsFilterModalOpen(false);
  };

  return (
    <div className="pb-24 pt-4 px-4 min-h-screen bg-gray-50">
      {/* Header */}
      <header className="flex justify-between items-center mb-6">
        <LocationPicker 
            selectedCircle={selectedCircle} 
            onSelect={handleLocationSelect} 
        />
        <NotificationBell />
      </header>

      {/* Search Bar */}
      <div className="flex gap-3 mb-8 sticky top-4 z-20">
        <div className="flex-1 relative shadow-sm rounded-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Search in ${selectedCircle?.name.split(',')[0]}...`} 
            className="w-full pl-12 pr-4 py-3 bg-white rounded-full border-none focus:ring-2 focus:ring-primary-400 outline-none text-gray-700 transition-shadow"
          />
        </div>
        <button 
          onClick={() => setIsFilterModalOpen(true)}
          className="bg-white p-3 rounded-full shadow-sm text-gray-700 hover:text-primary-600 transition-colors"
        >
          <SlidersHorizontal size={24} />
        </button>
      </div>

      {/* Stories / Community Hub */}
      <StoriesTray currentCircleId={selectedCircle?.id} />

      {/* Filter Chips */}
      <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar mt-2">
        {['All', 'For Sale', 'Trade', 'Donation'].map(chip => (
          <button 
            key={chip}
            onClick={() => setActiveChip(chip)}
            className={`px-5 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap ${
              activeChip === chip
              ? 'bg-primary-500 text-white shadow-md shadow-primary-200' 
              : 'bg-white text-gray-600 hover:bg-gray-100 border border-transparent'
            }`}
          >
            {chip}
          </button>
        ))}
      </div>

      {/* Grid Content */}
      {filteredListings.length > 0 ? (
        <div className="grid grid-cols-2 gap-4 animate-in fade-in duration-500">
          {filteredListings.map(listing => (
            <ListingCard key={listing.id} listing={listing} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-6 text-gray-400">
            <Search size={40} />
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">No items found</h3>
          <p className="text-gray-500 max-w-[250px] mb-8">
            Be the first to list something in <span className="font-bold text-gray-800">{selectedCircle?.name}</span>!
          </p>
          <div className="flex flex-col gap-3 w-full max-w-xs">
            <button 
                onClick={() => {
                setActiveChip('All');
                setSearchQuery('');
                setFilters({ distance: 25, priceMin: '', priceMax: '', condition: [], sortBy: 'newest' });
                }}
                className="flex items-center justify-center gap-2 px-6 py-3 bg-white border border-gray-200 rounded-full font-bold text-gray-700 hover:bg-gray-50 transition-colors shadow-sm"
            >
                <RotateCcw size={18} />
                Clear Filters
            </button>
          </div>
        </div>
      )}

      {/* Filter Modal */}
      <FilterModal 
        isOpen={isFilterModalOpen} 
        onClose={() => setIsFilterModalOpen(false)}
        onApply={handleApplyFilters}
        initialFilters={filters}
      />
    </div>
  );
};

export default HomeFeed;