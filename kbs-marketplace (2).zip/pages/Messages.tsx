import React, { useEffect, useState } from 'react';
import { Search, MoreVertical, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import { Conversation, AppUser } from '../types/database';

const Messages = () => {
  const navigate = useNavigate();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentUser] = useState<string>('current-user'); // In real app, get from auth context

  useEffect(() => {
    fetchConversations();
  }, []);

  const fetchConversations = async () => {
    try {
      // Real Fetch Logic
      // Note: In a real Supabase setup, we would join app_user to get details.
      // Since this is 2B iteration, we'll try to fetch, but fallback to mock if env keys aren't set.
      
      const { data, error } = await supabase
        .from('conversation')
        .select('*')
        .or(`participant1_id.eq.${currentUser},participant2_id.eq.${currentUser}`)
        .order('last_message_at', { ascending: false });

      if (error || !data) throw error;
      
      // For demo purposes, we need to populate 'other_user' manually if we didn't do a complex join
      // Here we just mock the "other user" data because we don't have a full user table populated in this context
      const enriched = data.map((c: any) => ({
        ...c,
        other_user: {
            id: c.participant1_id === currentUser ? c.participant2_id : c.participant1_id,
            name: c.participant1_id === currentUser ? 'Alice Baker' : 'Charlie Solar', // Mock name resolution
            avatar_url: `https://i.pravatar.cc/150?u=${c.id}`,
            city: 'Cincinnati',
            zip: '45202',
            reputation_score: 4.8,
            karma_points: 100
        } as AppUser
      }));
      
      setConversations(enriched);
    } catch (err) {
      console.warn("Supabase fetch failed (likely missing keys), falling back to mock data.", err);
      // Fallback Mock Data
      setConversations([
        {
          id: '1',
          participant1_id: 'current-user',
          participant2_id: 'u2',
          last_message: 'Is this still available? I can pick it up today.',
          last_message_at: new Date(Date.now() - 1000 * 60 * 2).toISOString(), // 2 mins ago
          updated_at: new Date().toISOString(),
          other_user: {
            id: 'u2',
            name: 'Alice Baker',
            avatar_url: 'https://i.pravatar.cc/150?u=Alice',
            city: 'Brooklyn',
            zip: '11201',
            reputation_score: 5.0,
            karma_points: 200
          },
          unread_count: 1
        },
        {
          id: '2',
          participant1_id: 'u3',
          participant2_id: 'current-user',
          last_message: 'Thanks for the trade! The chair is perfect.',
          last_message_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 hours ago
          updated_at: new Date().toISOString(),
          other_user: {
            id: 'u3',
            name: 'Charlie Solar',
            avatar_url: 'https://i.pravatar.cc/150?u=Charlie',
            city: 'Queens',
            zip: '11101',
            reputation_score: 4.5,
            karma_points: 50
          },
          unread_count: 0
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (isoString: string) => {
    const date = new Date(isoString);
    const now = new Date();
    const diff = (now.getTime() - date.getTime()) / 1000; // seconds

    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="px-4 py-4 border-b border-gray-100 sticky top-0 bg-white/80 backdrop-blur-md z-10 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Messages</h1>
        <button className="p-2 hover:bg-gray-50 rounded-full text-gray-500">
          <MoreVertical size={20} />
        </button>
      </header>

      {/* Search */}
      <div className="px-4 py-3">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="Search messages..." 
            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-primary-400 outline-none text-gray-700 text-sm"
          />
        </div>
      </div>

      {/* Conversation List */}
      {loading ? (
        <div className="flex justify-center p-8">
            <Loader2 className="animate-spin text-primary-500" size={32} />
        </div>
      ) : (
        <div className="divide-y divide-gray-50">
          {conversations.map(conv => (
            <div 
                key={conv.id} 
                onClick={() => navigate(`/messages/${conv.id}`)}
                className="flex items-center gap-4 p-4 hover:bg-gray-50 active:bg-gray-100 transition-colors cursor-pointer"
            >
              {/* Avatar */}
              <div className="relative">
                <img 
                  src={conv.other_user?.avatar_url || 'https://via.placeholder.com/150'} 
                  alt={conv.other_user?.name} 
                  className="w-12 h-12 rounded-full object-cover border border-gray-100"
                />
                {/* Status Indicator (Mock) */}
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-baseline mb-1">
                  <h3 className={`font-semibold truncate ${conv.unreadCount && conv.unreadCount > 0 ? 'text-gray-900' : 'text-gray-700'}`}>
                    {conv.other_user?.name || 'Unknown User'}
                  </h3>
                  <span className={`text-xs ${conv.unreadCount && conv.unreadCount > 0 ? 'text-primary-600 font-bold' : 'text-gray-400'}`}>
                    {formatTime(conv.last_message_at)}
                  </span>
                </div>
                <p className={`text-sm truncate ${conv.unreadCount && conv.unreadCount > 0 ? 'text-gray-900 font-medium' : 'text-gray-500'}`}>
                  {conv.last_message}
                </p>
              </div>

              {/* Unread Badge */}
              {conv.unreadCount && conv.unreadCount > 0 ? (
                <div className="w-5 h-5 bg-primary-500 rounded-full flex items-center justify-center text-white text-[10px] font-bold">
                  {conv.unreadCount}
                </div>
              ) : null}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Messages;